[**MuzaLife Frontend v0.1.0**](../../README.md)

***

[MuzaLife Frontend](../../modules.md) / [types](../README.md) / Order

# Interface: Order

Defined in: [types.ts:104](https://github.com/VladimiKoroviakov/muzalife_frontend/blob/821ccbf9db79ead771a747dfddddf23ce92a666e/src/types.ts#L104)

## Properties

### date

> **date**: `string`

Defined in: [types.ts:107](https://github.com/VladimiKoroviakov/muzalife_frontend/blob/821ccbf9db79ead771a747dfddddf23ce92a666e/src/types.ts#L107)

***

### formattedDate?

> `optional` **formattedDate?**: `string`

Defined in: [types.ts:109](https://github.com/VladimiKoroviakov/muzalife_frontend/blob/821ccbf9db79ead771a747dfddddf23ce92a666e/src/types.ts#L109)

***

### id

> **id**: `number`

Defined in: [types.ts:105](https://github.com/VladimiKoroviakov/muzalife_frontend/blob/821ccbf9db79ead771a747dfddddf23ce92a666e/src/types.ts#L105)

***

### materialType?

> `optional` **materialType?**: `string`

Defined in: [types.ts:110](https://github.com/VladimiKoroviakov/muzalife_frontend/blob/821ccbf9db79ead771a747dfddddf23ce92a666e/src/types.ts#L110)

***

### name

> **name**: `string`

Defined in: [types.ts:106](https://github.com/VladimiKoroviakov/muzalife_frontend/blob/821ccbf9db79ead771a747dfddddf23ce92a666e/src/types.ts#L106)

***

### orderDate?

> `optional` **orderDate?**: `string`

Defined in: [types.ts:108](https://github.com/VladimiKoroviakov/muzalife_frontend/blob/821ccbf9db79ead771a747dfddddf23ce92a666e/src/types.ts#L108)
