[**MuzaLife Frontend v0.1.0**](../../README.md)

***

[MuzaLife Frontend](../../modules.md) / [types](../README.md) / UseSingleProduct

# Interface: UseSingleProduct

Defined in: [types.ts:181](https://github.com/VladimiKoroviakov/muzalife_frontend/blob/821ccbf9db79ead771a747dfddddf23ce92a666e/src/types.ts#L181)

## Properties

### error

> **error**: `string` \| `null`

Defined in: [types.ts:186](https://github.com/VladimiKoroviakov/muzalife_frontend/blob/821ccbf9db79ead771a747dfddddf23ce92a666e/src/types.ts#L186)

***

### galleryImages

> **galleryImages**: `string`[]

Defined in: [types.ts:184](https://github.com/VladimiKoroviakov/muzalife_frontend/blob/821ccbf9db79ead771a747dfddddf23ce92a666e/src/types.ts#L184)

***

### loading

> **loading**: `boolean`

Defined in: [types.ts:185](https://github.com/VladimiKoroviakov/muzalife_frontend/blob/821ccbf9db79ead771a747dfddddf23ce92a666e/src/types.ts#L185)

***

### product

> **product**: [`Product`](../type-aliases/Product.md) \| `null`

Defined in: [types.ts:182](https://github.com/VladimiKoroviakov/muzalife_frontend/blob/821ccbf9db79ead771a747dfddddf23ce92a666e/src/types.ts#L182)

***

### refetch

> **refetch**: () => `Promise`\<`void`\>

Defined in: [types.ts:187](https://github.com/VladimiKoroviakov/muzalife_frontend/blob/821ccbf9db79ead771a747dfddddf23ce92a666e/src/types.ts#L187)

#### Returns

`Promise`\<`void`\>

***

### reviews

> **reviews**: [`Review`](Review.md)[]

Defined in: [types.ts:183](https://github.com/VladimiKoroviakov/muzalife_frontend/blob/821ccbf9db79ead771a747dfddddf23ce92a666e/src/types.ts#L183)
