[**MuzaLife Frontend v0.1.0**](../../README.md)

***

[MuzaLife Frontend](../../modules.md) / [types](../README.md) / UpdatePersonalOrderData

# Interface: UpdatePersonalOrderData

Defined in: [types.ts:62](https://github.com/VladimiKoroviakov/muzalife_frontend/blob/821ccbf9db79ead771a747dfddddf23ce92a666e/src/types.ts#L62)

## Properties

### orderDeadline?

> `optional` **orderDeadline?**: `string` \| `null`

Defined in: [types.ts:69](https://github.com/VladimiKoroviakov/muzalife_frontend/blob/821ccbf9db79ead771a747dfddddf23ce92a666e/src/types.ts#L69)

***

### orderDescription?

> `optional` **orderDescription?**: `string`

Defined in: [types.ts:64](https://github.com/VladimiKoroviakov/muzalife_frontend/blob/821ccbf9db79ead771a747dfddddf23ce92a666e/src/types.ts#L64)

***

### orderMaterialAgeCategory?

> `optional` **orderMaterialAgeCategory?**: `string`

Defined in: [types.ts:68](https://github.com/VladimiKoroviakov/muzalife_frontend/blob/821ccbf9db79ead771a747dfddddf23ce92a666e/src/types.ts#L68)

***

### orderMaterialType?

> `optional` **orderMaterialType?**: `string`

Defined in: [types.ts:67](https://github.com/VladimiKoroviakov/muzalife_frontend/blob/821ccbf9db79ead771a747dfddddf23ce92a666e/src/types.ts#L67)

***

### orderPrice?

> `optional` **orderPrice?**: `number`

Defined in: [types.ts:66](https://github.com/VladimiKoroviakov/muzalife_frontend/blob/821ccbf9db79ead771a747dfddddf23ce92a666e/src/types.ts#L66)

***

### orderStatus?

> `optional` **orderStatus?**: `string`

Defined in: [types.ts:65](https://github.com/VladimiKoroviakov/muzalife_frontend/blob/821ccbf9db79ead771a747dfddddf23ce92a666e/src/types.ts#L65)

***

### orderTitle?

> `optional` **orderTitle?**: `string`

Defined in: [types.ts:63](https://github.com/VladimiKoroviakov/muzalife_frontend/blob/821ccbf9db79ead771a747dfddddf23ce92a666e/src/types.ts#L63)
