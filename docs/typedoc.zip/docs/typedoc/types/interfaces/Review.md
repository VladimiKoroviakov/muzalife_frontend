[**MuzaLife Frontend v0.1.0**](../../README.md)

***

[MuzaLife Frontend](../../modules.md) / [types](../README.md) / Review

# Interface: Review

Defined in: [types.ts:170](https://github.com/VladimiKoroviakov/muzalife_frontend/blob/821ccbf9db79ead771a747dfddddf23ce92a666e/src/types.ts#L170)

## Properties

### comment

> **comment**: `string`

Defined in: [types.ts:177](https://github.com/VladimiKoroviakov/muzalife_frontend/blob/821ccbf9db79ead771a747dfddddf23ce92a666e/src/types.ts#L177)

***

### createdAt

> **createdAt**: `string`

Defined in: [types.ts:178](https://github.com/VladimiKoroviakov/muzalife_frontend/blob/821ccbf9db79ead771a747dfddddf23ce92a666e/src/types.ts#L178)

***

### id

> **id**: `number`

Defined in: [types.ts:171](https://github.com/VladimiKoroviakov/muzalife_frontend/blob/821ccbf9db79ead771a747dfddddf23ce92a666e/src/types.ts#L171)

***

### productId

> **productId**: `number`

Defined in: [types.ts:172](https://github.com/VladimiKoroviakov/muzalife_frontend/blob/821ccbf9db79ead771a747dfddddf23ce92a666e/src/types.ts#L172)

***

### rating

> **rating**: `number`

Defined in: [types.ts:176](https://github.com/VladimiKoroviakov/muzalife_frontend/blob/821ccbf9db79ead771a747dfddddf23ce92a666e/src/types.ts#L176)

***

### userAvatar?

> `optional` **userAvatar?**: `string`

Defined in: [types.ts:175](https://github.com/VladimiKoroviakov/muzalife_frontend/blob/821ccbf9db79ead771a747dfddddf23ce92a666e/src/types.ts#L175)

***

### userId

> **userId**: `number`

Defined in: [types.ts:173](https://github.com/VladimiKoroviakov/muzalife_frontend/blob/821ccbf9db79ead771a747dfddddf23ce92a666e/src/types.ts#L173)

***

### userName

> **userName**: `string`

Defined in: [types.ts:174](https://github.com/VladimiKoroviakov/muzalife_frontend/blob/821ccbf9db79ead771a747dfddddf23ce92a666e/src/types.ts#L174)
